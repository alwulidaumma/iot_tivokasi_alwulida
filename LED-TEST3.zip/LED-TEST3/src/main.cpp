#include <Arduino.h>

// Definisi pin untuk tombol
const int tombol1 = 34;
const int tombol2 = 35;
const int tombol3 = 33;

// Definisi pin untuk LED
const int ledMerah = 23;
const int ledKuning = 22;
const int ledHijau = 21;

void setup() {
    // Konfigurasi tombol sebagai input dengan pull-up internal
    pinMode(tombol1, INPUT_PULLUP);
    pinMode(tombol2, INPUT_PULLUP);
    pinMode(tombol3, INPUT_PULLUP);

    // Konfigurasi LED sebagai output
    pinMode(ledMerah, OUTPUT);
    pinMode(ledKuning, OUTPUT);
    pinMode(ledHijau, OUTPUT);

    // Pastikan semua LED mati saat mulai
    digitalWrite(ledMerah, LOW);
    digitalWrite(ledKuning, LOW);
    digitalWrite(ledHijau, LOW);
}

void loop() {
    if (digitalRead(tombol1) == LOW) {
        // LED merah berkedip 5 kali
        for (int i = 0; i < 5; i++) {
            digitalWrite(ledMerah, HIGH);
            delay(300);
            digitalWrite(ledMerah, LOW);
            delay(300);
        }
    } 
    
    else if (digitalRead(tombol2) == LOW) {
        // LED merah dan hijau berkedip bergantian
        for (int i = 0; i < 5; i++) {
            digitalWrite(ledMerah, HIGH);
            digitalWrite(ledHijau, LOW);
            delay(300);
            digitalWrite(ledMerah, LOW);
            digitalWrite(ledHijau, HIGH);
            delay(300);
        }
        digitalWrite(ledHijau, LOW);
    } 
    
    else if (digitalRead(tombol3) == LOW) {
        // LED merah, kuning, hijau berkedip bergantian
        for (int i = 0; i < 5; i++) {
            digitalWrite(ledMerah, HIGH);
            delay(200);
            digitalWrite(ledMerah, LOW);
            digitalWrite(ledKuning, HIGH);
            delay(200);
            digitalWrite(ledKuning, LOW);
            digitalWrite(ledHijau, HIGH);
            delay(200);
            digitalWrite(ledHijau, LOW);
        }
    }
}
